import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import Import from './components/Import';
import Results from './components/Results';
import History from './components/History';
import Settings from './components/Settings';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/import" component={Import} />
        <Route path="/results" component={Results} />
        <Route path="/history" component={History} />
        <Route path="/settings" component={Settings} />
      </Switch>
    </Router>
  );
}

export default App;
